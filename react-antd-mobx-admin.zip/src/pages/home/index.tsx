import './home.less'
import React from 'react'
const Home = () => {
    return (
        <div className="home">
            123
        </div>
    )
}

export default Home