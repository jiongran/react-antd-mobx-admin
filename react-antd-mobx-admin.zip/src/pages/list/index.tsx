import React from 'react'
const List = ()=>{
    return (
        <>
        list1
        </>
    )
}

export default List