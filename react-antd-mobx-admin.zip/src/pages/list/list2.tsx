import React from 'react'
const List2 = ()=>{
    return (
        <>
        list2
        </>
    )
}

export default List2